package com.mindhub.homebanking.controllers;

import com.mindhub.homebanking.dtos.frontend.LoanApplicationDTO;
import com.mindhub.homebanking.dtos.LoanDTO;
import com.mindhub.homebanking.models.*;
import com.mindhub.homebanking.models.enums.TransactionType;
import com.mindhub.homebanking.repositories.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import javax.transaction.Transactional;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api")
@CrossOrigin
public class LoanController {
    @Autowired
    private ClientRepository clientRepository;

    @Autowired
    private LoanRepository loanRepository;

    @Autowired
    private AccountRepository accountRepository;

    @Autowired
    private TransactionRepository transactionRepository;

    @Autowired
    private ClientLoanRepository clientLoanRepository;

    @Transactional
    @PostMapping("/clients/current/loans")
    public ResponseEntity<?> createLoan(@RequestBody LoanApplicationDTO loanApplicationDTO, Authentication authentication){

        Client client = this.clientRepository.findByEmail(authentication.getName()); //OBTENER EL CLIENTE AUTENTIFICADO
        Account account = this.accountRepository.findByNumber(loanApplicationDTO.getName()); //RECUPERAR CUENTA DE DESTINO
        Optional<Loan> loan = this.loanRepository.findById(loanApplicationDTO.getId());


        if(loanApplicationDTO.getAmount() == 0 || loanApplicationDTO.getName() == null || loanApplicationDTO.getPayments() == 0){
            return new ResponseEntity<>("LLENA LOS CAMPOS BOLUDO", HttpStatus.FORBIDDEN);
        }
        if(loan.isEmpty()){
            return new ResponseEntity<>("VACIO", HttpStatus.FORBIDDEN);
        }

        if(loanApplicationDTO.getAmount() > loan.get().getMaxamount()){
            return new ResponseEntity<>("MONTO INSUFICIENTE", HttpStatus.FORBIDDEN);
        }

        //Verifica que la cantidad de cuotas se encuentre entre las disponibles del préstamo

        if(!loan.get().getPayments().contains(loanApplicationDTO.getPayments())){
            return new ResponseEntity<>("PAYMENT NADA QUE VER", HttpStatus.FORBIDDEN);
        }

        if(account == null){
            return new ResponseEntity<>("NO EXISTE LA CUENTA", HttpStatus.FORBIDDEN);
        }

        if(loanApplicationDTO.getAmount() <= 0){
            return new ResponseEntity<>("THE AMOUNT IS INVALID", HttpStatus.FORBIDDEN);
        }

        if(!client.getAccounts().contains(account)){
            return new ResponseEntity<>("NO EXISTE LA CUENTA DEL CLIENTE AUTENTIFICADO", HttpStatus.FORBIDDEN);
        }

        this.clientLoanRepository.save(new ClientLoan(loanApplicationDTO.getAmount() + (loanApplicationDTO.getAmount() * 0.20), loanApplicationDTO.getPayments(), client,loan.get()));
        this.transactionRepository.save(new Transaction(loanApplicationDTO.getAmount(),"LOAN APPROVED " + loanApplicationDTO.getName(), TransactionType.CREDIT, LocalDateTime.now(),account));



        return new ResponseEntity<>("LOAN COMPLETED", HttpStatus.OK);
    }

    @GetMapping("/clients/current/loans")
    public List<LoanDTO> getLoans(){
        return this.loanRepository.findAll().stream().map(LoanDTO :: new).collect(Collectors.toList());
    }

}
