package com.mindhub.homebanking.dtos.frontend;

public class AccountBuyAplicationDTO {
}
