package com.mindhub.homebanking;

import com.mindhub.homebanking.models.*;
import com.mindhub.homebanking.models.enums.CardColorType;
import com.mindhub.homebanking.models.enums.CardType;
import com.mindhub.homebanking.models.enums.TransactionType;
import com.mindhub.homebanking.repositories.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.time.LocalDateTime;
import java.util.List;

@SpringBootApplication
public class HomebankingApplication {

	@Autowired
	PasswordEncoder passwordEnconder;


	public static void main(String[] args) {
		SpringApplication.run(HomebankingApplication.class, args);
	}

	@Bean
	public CommandLineRunner initData(ClientRepository repository, AccountRepository accountRepository, TransactionRepository transactionRepository, LoanRepository loanRepository, ClientLoanRepository clientLoanRepository, CardRepository cardRepository) {
		return (args) -> {
			LocalDateTime today = LocalDateTime.now();
			LocalDateTime tomorrow = today.plusDays(1);
			LocalDateTime fiveYears = today.plusYears(5);
			LocalDateTime yesterday = today.plusYears(-1);


			Loan loan_1 = loanRepository.save(new Loan("Mortgage",500000.00, List.of(2,4,6)));
			Loan loan_2 = loanRepository.save( new Loan("Personal",100000.00, List.of(2,4)));
			Loan loan_3 = loanRepository.save( new Loan("Automotive",300000.00, List.of(2)));

			//------------CLIENT 1-----------
			Client client_1 = repository.save(new Client("Mabel", "Morel", "mabel@gmail.com",passwordEnconder.encode("123")));

			Account account_1 = accountRepository.save(new Account("VIN001", today,5000.00,client_1));
			Account account_2 = accountRepository.save(new Account("VIN002", tomorrow,7500.00,client_1));



			Transaction transaction_1 = transactionRepository.save(new Transaction(2500.50,"DOUT", TransactionType.CREDIT, today,account_1));
			Transaction transaction_2 = transactionRepository.save(new Transaction(-1000,"Buy with card debit",TransactionType.DEBIT,today,account_2));

			ClientLoan clientLoan_1 = clientLoanRepository.save(new ClientLoan( 200000.00,2,client_1,loan_2));
			ClientLoan clientLoan_2 = clientLoanRepository.save(new ClientLoan( 350000.00,2,client_1,loan_1));

			Card card_1 = cardRepository.save(new Card(CardType.CREDIT, CardColorType.SILVER, "3002 2903 0861 1241", 191, today, yesterday,client_1));
			Card card_3 = cardRepository.save(new Card(CardType.DEBIT, CardColorType.GOLD, "1455 6781 2345 4567", 123,today, fiveYears, client_1));


			//------------CLIENT 2-----------
			Client client_2 = repository.save(new Client("Agustin", "Estrada", "aguss@gmail.com",""));

			Account account_3 = accountRepository.save(new Account("VIN003", tomorrow,7500.00,client_2));

			Transaction transaction_3 = transactionRepository.save(new Transaction(-3500.50,"COMPRA EXTRERIOR",TransactionType.DEBIT,today,account_3));

			ClientLoan clientLoan_3 = clientLoanRepository.save(new ClientLoan( 150000.00,2,client_2,loan_2));
			ClientLoan clientLoan_4 = clientLoanRepository.save(new ClientLoan( 700.50,2,client_2,loan_3));

			Card card_2 = cardRepository.save(new Card(CardType.CREDIT, CardColorType.SILVER, "300290086", 181,fiveYears ,today,client_2));




		};
	}

}

