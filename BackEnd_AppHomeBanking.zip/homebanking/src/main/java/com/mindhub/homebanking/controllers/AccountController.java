package com.mindhub.homebanking.controllers;

import com.mindhub.homebanking.dtos.AccountDTO;
import com.mindhub.homebanking.models.*;
import com.mindhub.homebanking.models.enums.CardColorType;
import com.mindhub.homebanking.models.enums.CardType;
import com.mindhub.homebanking.models.enums.TransactionType;
import com.mindhub.homebanking.repositories.*;
import com.mindhub.homebanking.service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api")
@CrossOrigin
public class AccountController {

    @Autowired
    private AccountRepository accountRepository;
    @Autowired
    private ClientRepository clientRepository;
    @Autowired
    private AccountService accountService;
    @Autowired
    private CardRepository cardRepository;
    @Autowired
    private TransactionRepository transactionRepository;



    @GetMapping("/accounts")
    public List<AccountDTO> getAccounts(){

        return this.accountRepository.findAll().stream().map(AccountDTO::new).collect(Collectors.toList());
    }



    @GetMapping("/accounts/{id}")
    public AccountDTO getAccount(@PathVariable Long id){
        return this.accountRepository.findById(id).map(x -> new AccountDTO(x)).orElse(null);
    }


    //CREAR UNA CUENTA
    @PostMapping("/clients/current/accounts")
    public ResponseEntity<?> postAccount(Authentication authentication, @RequestParam Boolean createNewAccount ){

        Client client = this.clientRepository.findByEmail(authentication.getName()); //OBTENER EL CLIENTE AUTENTIFICADO

        if(client == null){ //COMPARO SI ES NULA LA AUTENTIFICACION
            return new ResponseEntity<>("Authenticated client is not recognized", HttpStatus.FORBIDDEN);
        }

        if(client.getAccounts().size() >= 3){ //VALIDACION DE CUENTAS CREADAS POR EL CLIENTE AUTENTIFICADO

            return new ResponseEntity<>("You reached the maximum number of gutters", HttpStatus.FORBIDDEN);
        }

        String numberRandom = "VIN00" + (accountRepository.findAll().size() + 1); //Variable para el numero de cuenta

        if(createNewAccount){ //CONDICION PARA VALIDAR UN REQUEST PARAM y BOOLEAN PARA LA CUENTA CREADA
            accountRepository.save(new Account(numberRandom, LocalDateTime.now(),0,client)); //GUARDAR UNA NUEVA CUENTA
            return new ResponseEntity<>("Authenticated client is not recognized", HttpStatus.OK);
        }

        return new ResponseEntity<>("Authenticated client is not recognized", HttpStatus.FORBIDDEN);
    }

    @GetMapping("/clients/current/accounts")
    public List<AccountDTO> getAccount(Authentication authentication){
        return this.accountRepository.findAll().stream().map(AccountDTO::new).collect(Collectors.toList());
    }
    //TERMINAR LO DE BORRAR LAS TRANSACCIONES
    @DeleteMapping("/account/{id}")
    public ResponseEntity<?> deleteAccount( @PathVariable Long id, @PathVariable List transaction ){
        this.accountRepository.deleteById(id);
        return new ResponseEntity<>("DELETE ACCOUNT", HttpStatus.OK);
    }

    //COMPRA DE CRIPTOMONEDAS
    @PostMapping("/clients/current/buy")
    public ResponseEntity<?> buyCrypto(@RequestParam String number,@RequestParam Double amountBuyCrypto, @RequestParam String description){
        Account account = this.accountRepository.findByNumber(number);
        if(account == null){
            return new ResponseEntity<>("ACCOUNT NOT FOUND", HttpStatus.FORBIDDEN);
        }
        if(amountBuyCrypto <= 0){
            return new ResponseEntity<>("INVALID AMOUNT", HttpStatus.FORBIDDEN);
        }

        if(amountBuyCrypto > account.getBalance()){
            return new ResponseEntity<>("YOU HAVE NOT MONEY", HttpStatus.FORBIDDEN);
        }

        transactionRepository.save(new Transaction(-amountBuyCrypto, "Buy cypto" , TransactionType.DEBIT, LocalDateTime.now(), account));
        return new ResponseEntity<>("BUY COMPLETED", HttpStatus.OK);
    }
}
