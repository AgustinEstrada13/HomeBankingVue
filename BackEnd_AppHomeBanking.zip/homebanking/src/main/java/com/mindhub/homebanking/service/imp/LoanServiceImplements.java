package com.mindhub.homebanking.service.imp;

import com.mindhub.homebanking.models.Loan;
import com.mindhub.homebanking.service.LoanService;

public class LoanServiceImplements  implements LoanService {
    @Override
    public Boolean newLoan(Loan loan) {
        return null;
    }
}
