package com.mindhub.homebanking.models.enums;

public enum TransactionType {
    DEBIT,CREDIT
}
