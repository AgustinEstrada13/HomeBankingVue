package com.mindhub.homebanking.models.enums;

public enum CardColorType {
    SILVER,GOLD,PLATINUM
}
