package com.mindhub.homebanking.dtos.frontend;

import com.mindhub.homebanking.models.Account;

// CLASE PARA ENVIAR LOS DATOS POR EL REQUEST BODY
public class LoanApplicationDTO {
    private long id;
    private double amount;
    private int payments;
    private String name;

    public LoanApplicationDTO() {
    }

    public LoanApplicationDTO(long id, double amount, int payments, String name) {
        this.id = id;
        this.amount = amount;
        this.payments = payments;
        this.name = name;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public int getPayments() {
        return payments;
    }

    public void setPayments(int payments) {
        this.payments = payments;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
