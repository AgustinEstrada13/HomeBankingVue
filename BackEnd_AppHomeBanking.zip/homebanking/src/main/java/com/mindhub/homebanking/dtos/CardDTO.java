package com.mindhub.homebanking.dtos;

import com.mindhub.homebanking.models.Card;
import com.mindhub.homebanking.models.enums.CardColorType;
import com.mindhub.homebanking.models.enums.CardType;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class CardDTO {
    private Long cardId;
    private String cardholder; //get name & last name from client
    private CardType typecard;
    private CardColorType colorCard;
    private String number;
    private Integer cvv;
    private LocalDateTime fromDate;
    private LocalDateTime thruDate;
    private boolean expiredCard;

    private Set<String> client = new HashSet<>();

    public CardDTO() {
    }

    public CardDTO(Card card) {
        this.cardId = card.getId();
        this.cardholder = card.getCardholder();
        this.typecard = card.getTypecard();
        this.colorCard = card.getColorCard();
        this.number = card.getNumber();
        this.cvv = card.getCvv();
        this.fromDate = card.getFromDate();
        this.thruDate = card.getThruDate();
        this.client.add(card.getClient().firstName);
        this.client.add(card.getClient().lastName);
        this.client.add(card.getClient().email);
        this.expiredCard = expiredCard();
    }

    public Boolean expiredCard(){
        if(thruDate.compareTo(fromDate) < 0){
            return true;
        }
        return false;
    }

    public Long getCardId() {
        return cardId;
    }

    public void setCardId(Long cardId) {
        this.cardId = cardId;
    }

    public String getCardholder() {
        return cardholder;
    }

    public void setCardholder(String cardholder) {
        this.cardholder = cardholder;
    }

    public boolean isExpiredCard() {
        return expiredCard;
    }

    public void setExpiredCard(boolean expiredCard) {
        this.expiredCard = expiredCard;
    }

    public CardType getTypecard() {
        return typecard;
    }

    public void setTypecard(CardType typecard) {
        this.typecard = typecard;
    }

    public CardColorType getColorCard() {
        return colorCard;
    }

    public void setColorCard(CardColorType colorCard) {
        this.colorCard = colorCard;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public Integer getCvv() {
        return cvv;
    }

    public void setCvv(Integer cvv) {
        this.cvv = cvv;
    }

    public LocalDateTime getFromDate() {
        return fromDate;
    }

    public void setFromDate(LocalDateTime fromDate) {
        this.fromDate = fromDate;
    }

    public LocalDateTime getThruDate() {
        return thruDate;
    }

    public void setThruDate(LocalDateTime thruDate) {
        this.thruDate = thruDate;
    }

    public Set<String> getClient() {
        return client;
    }

    public void setClient(Set<String> client) {
        this.client = client;
    }
}
