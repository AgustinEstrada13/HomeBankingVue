package com.mindhub.homebanking.service;

import com.mindhub.homebanking.models.Card;

public interface CardService {
    Boolean expiredCard(Card card);
}
