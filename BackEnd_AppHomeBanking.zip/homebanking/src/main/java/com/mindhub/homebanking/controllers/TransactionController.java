package com.mindhub.homebanking.controllers;

import com.mindhub.homebanking.models.Account;
import com.mindhub.homebanking.models.Client;
import com.mindhub.homebanking.models.Transaction;
import com.mindhub.homebanking.models.enums.TransactionType;
import com.mindhub.homebanking.repositories.AccountRepository;
import com.mindhub.homebanking.repositories.ClientRepository;
import com.mindhub.homebanking.repositories.TransactionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import javax.transaction.Transactional;
import java.time.LocalDateTime;

@RestController
@RequestMapping("/api")
@CrossOrigin
public class TransactionController {
    @Autowired
    private ClientRepository clientRepository;

    @Autowired
    private AccountRepository accountRepository;

    @Autowired
    private TransactionRepository transactionRepository;

    @Transactional
    @PostMapping("/current/transfer")
    public ResponseEntity<?> transfer (Authentication authentication, @RequestParam Double amount,@RequestParam String description, @RequestParam String fromAccount,@RequestParam String toAccount){
        Client client = this.clientRepository.findByEmail(authentication.getName()); //OBTENER EL CLIENTE AUTENTIFICADO
        Account FromAccount = this.accountRepository.findByNumber(fromAccount);
        Account ToAccount = this.accountRepository.findByNumber(toAccount);

        if(amount == null || description == null || fromAccount == null || toAccount == null){
            return new ResponseEntity<>("CAMPOS INCOMPLETOS", HttpStatus.FORBIDDEN);
        }

        if(fromAccount.equalsIgnoreCase(toAccount)){ //----toque
            return new ResponseEntity<>("CUENTAS IGUALES", HttpStatus.FORBIDDEN);
        }

        if (accountRepository.findByNumber(fromAccount) == null) {
            return new ResponseEntity<>("CUENTA NO EXISTE", HttpStatus.FORBIDDEN);
        }
        if(!client.getAccounts().contains(FromAccount) && !client.getAccounts().contains(ToAccount)){
            return new ResponseEntity<>("CUENTA NO EXISTE", HttpStatus.FORBIDDEN);
        }
        if(amount > FromAccount.getBalance()) {
            return new ResponseEntity<>("INSUFFICIENT BALANCE", HttpStatus.FORBIDDEN);
        }
        if(amount == 0){
            return new ResponseEntity<>("INVALID AMOUNT", HttpStatus.FORBIDDEN);
        }
        transactionRepository.save(new Transaction(-amount, description + ToAccount.getNumber(), TransactionType.DEBIT, LocalDateTime.now(), FromAccount));
        transactionRepository.save(new Transaction(amount, description + FromAccount.getNumber(), TransactionType.CREDIT, LocalDateTime.now(), ToAccount));


        return new ResponseEntity<>("TRANSACTION REALIZED", HttpStatus.OK);
    }

}
