package com.mindhub.homebanking.service.imp;

import com.mindhub.homebanking.dtos.AccountDTO;
import com.mindhub.homebanking.models.Account;
import com.mindhub.homebanking.models.Client;
import com.mindhub.homebanking.models.Transaction;
import com.mindhub.homebanking.repositories.AccountRepository;
import com.mindhub.homebanking.repositories.ClientRepository;
import com.mindhub.homebanking.service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.Set;


@Service
public class AccountServiceImplements implements AccountService {
    @Autowired
    private AccountRepository accountRepository;
    @Autowired
    private ClientRepository clientRepository;


    @Override
    public Boolean newAccountRegister(Client client) {
        String numberRandom = "VIN00" + (accountRepository.findAll().size() + 1); //Variable para el numero de cuenta

        if(accountRepository.findAll().size() < 9999){
            accountRepository.save(new Account(numberRandom, LocalDateTime.now(),0,client)); //GUARDAR UNA NUEVA CUENTA
            return true;
        }


        return false;
    }

    public static double calculateBalance(Set<Transaction> transactions , Account accountOrigin) {
        double balance = accountOrigin.getBalance();
        for (Transaction transaction : transactions) {
            balance = balance + transaction.getAmount();}
        return balance;     }
}
