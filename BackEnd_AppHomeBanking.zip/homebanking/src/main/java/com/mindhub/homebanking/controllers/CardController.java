package com.mindhub.homebanking.controllers;

import com.mindhub.homebanking.dtos.CardDTO;
import com.mindhub.homebanking.models.Card;
import com.mindhub.homebanking.models.Client;
import com.mindhub.homebanking.models.enums.CardColorType;
import com.mindhub.homebanking.models.enums.CardType;
import com.mindhub.homebanking.repositories.CardRepository;
import com.mindhub.homebanking.repositories.ClientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api")
@CrossOrigin
public class CardController {

    @Autowired
    ClientRepository clientRepository;

    @Autowired
    CardRepository cardRepository;

    @GetMapping("/cards")
    public List<CardDTO> getCards() {
        return this.cardRepository.findAll().stream().map(CardDTO::new).collect(Collectors.toList());
    }

    @GetMapping("/cards/{id}")
    public CardDTO getCard(@PathVariable Long id){
        return this.cardRepository.findById(id).map(CardDTO::new).orElse(null);
    }

    //AGREGAR UNA TARJETA
    @PostMapping("/clients/current/cards")
    public ResponseEntity<?> postCard(Authentication authentication, @RequestParam CardType cardType, @RequestParam CardColorType cardColorType,
                                      @RequestParam int cvv ){
        Client client = this.clientRepository.findByEmail(authentication.getName());
        String numberRandom = "0034 23" + (cardRepository.findAll().size() + 10) + "8462 14" + (cardRepository.findAll().size() + 17); //Variable para el numero de cuenta
        if (client.getCards().size()<=5){
            cardRepository.save(new Card(cardType, cardColorType,numberRandom,cvv, LocalDateTime.now(),LocalDateTime.now().plusYears(5),client));
            return new ResponseEntity<>("CREATE NEW CARD ", HttpStatus.OK);
        }else{
            return new ResponseEntity<>("YOU HAVE MANY CARDS", HttpStatus.FORBIDDEN);
        }

    }

    //ELIMINAR TARJETA
    @DeleteMapping("clients/current/cards/{id}")
    public ResponseEntity<?> deleteCard( @PathVariable Long id  ){
        this.cardRepository.deleteById(id);
        return new ResponseEntity<>("DELETE CARD", HttpStatus.OK);
    }
}
