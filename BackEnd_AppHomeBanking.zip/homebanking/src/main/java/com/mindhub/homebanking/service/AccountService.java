package com.mindhub.homebanking.service;
import com.mindhub.homebanking.models.Client;



public interface AccountService {
    Boolean newAccountRegister(Client client);

}
