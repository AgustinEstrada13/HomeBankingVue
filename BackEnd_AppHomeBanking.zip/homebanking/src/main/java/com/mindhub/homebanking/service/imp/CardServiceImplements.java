package com.mindhub.homebanking.service.imp;

import com.mindhub.homebanking.models.Card;
import com.mindhub.homebanking.service.CardService;

public class CardServiceImplements implements CardService {
    @Override
    public Boolean expiredCard(Card card) {
        if(card.getThruDate().compareTo(card.getFromDate()) < 0){
            return true;
        }
        return false;
    }
}
