package com.mindhub.homebanking.service;

import com.mindhub.homebanking.models.Loan;

public interface LoanService {
    Boolean newLoan(Loan loan);


}
