package com.mindhub.homebanking.models.enums;

public enum CardType {
    DEBIT,CREDIT
}
