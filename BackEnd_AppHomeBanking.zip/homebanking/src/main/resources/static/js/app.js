const app = Vue.createApp({
    data(){
        return{
            clients:[],
            firstName:"",
            lastName:"",
            email:"",
        }

    },
    created(){
        axios.get("/rest/clients")
        .then(res => {
            this.clients = res.data._embedded.clients
            console.log(this.clients)})
        fetch.post('http://localhost:8080/api/login',"email=mabel@gmail.com&password=holaMundo1",{headers:{'content-type':'application/x-www-form-urlencoded'}}).then(response => console.log('signed in!!!'))

    },
    methods:{
        sendUserData() {
            axios.post('/rest/clients', {
                firstName: this.firstName,
                lastName: this.lastName,
                email: this.email,

            })

            location.reload();
        },

        deleteUser(client){
            axios.delete(client._links.client.href)
            location.reload()
        }
    }
})

app.mount("#app")