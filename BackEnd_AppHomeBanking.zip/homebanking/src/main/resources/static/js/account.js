const app = Vue.createApp({
    data(){
        return{
            accounts:[],

        }

    },
    created(){
        axios.get('/api/clients/1')
        .then(res => {
            this.accounts = res.data.accounts;
            console.log(this.accounts)
            
            
        })
        .catch(err => console.log(err))


    },
    methods:{





    }
})

app.mount("#app_account")